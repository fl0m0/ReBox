/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.7
        Device            :  PIC16F18326
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include "rebox.h"
#include "i2c.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"

// Global variables
operating_mode_t operating_mode = STARTUP;
uint8_t relay_states = 0x00; // 0 = relay open
// Color definitions
uint8_t COLOR_RED[3]    = {0xC0,0x00,0x00};
uint8_t COLOR_GREEN[3]  = {0x00,0x80,0x00};
uint8_t COLOR_BLUE[3]   = {0x00,0x00,0xFF};
uint8_t COLOR_YELLOW[3] = {0xD0,0x80,0x00};
uint8_t COLOR_CYAN[3]   = {0x00,0xC0,0xFF};
uint8_t COLOR_VIOLET[3] = {0xC0,0x00,0xFF};
uint8_t COLOR_WHITE[3]  = {0xFF,0x60,0x40};
uint8_t COLOR_OFF[3]    = {0x00,0x00,0x00};
uint8_t COLORS[21]      = {0xC0,0x00,0x00,  // red
                           0x00,0x80,0x00,  // green
                           0x00,0x00,0xFF,  // blue
                           0xD0,0x80,0x00,  // yellow
                           0x00,0xC0,0xFF,  // cyan
                           0xC0,0x00,0xFF,  // violet
                           0xFF,0x60,0x40}; // white

// Timer0: Used for detection of long (> 2 s) push button presses
// Timer2: Used for Super Loop, sets tmr0_trigger, 64 ms


/*
                         Main application
 */
void main(void)
{
    // I2C dadresses
    i2c1_address_t led_ctrl0_addr = LED_CTRL0_ADDR;
    i2c1_address_t led_ctrl1_addr = LED_CTRL1_ADDR;
    i2c1_address_t led_ctrl2_addr = LED_CTRL2_ADDR;
    i2c1_address_t led_ctrl3_addr = LED_CTRL3_ADDR;
    i2c1_address_t io_ctrl_addr = IO_CTRL_ADDR;
    // Green status LED on PCB, flashes in super loop
    uint8_t status_led_state = 0; // 0 = off
    uint8_t pb_states = 0x00; // 0 for pressed, bitwise
    uint8_t pb_rising_edges = 0x00; // 1 for rising edge, bitwise
    uint8_t pb7_long_press = 0;


    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    // INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    // INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    // Configure IO expander in/out pins, initial states
    io_ctrl_cfg(io_ctrl_addr, IO_CTRL_CFG_REGS, IO_CTRL_OUT_REGS);
 
 
 
    // Init LED controllers
    PCA9955B_init(led_ctrl0_addr);
    PCA9955B_init(led_ctrl1_addr);
    PCA9955B_init(led_ctrl2_addr);
    PCA9955B_init(led_ctrl3_addr);
    set_pb_color(CH1_LED, COLOR_RED);
    set_pb_color(CH2_LED, COLOR_GREEN);
    set_pb_color(CH3_LED, COLOR_BLUE);
    set_pb_color(CH4_LED, COLOR_YELLOW);
    set_pb_color(CH5_LED, COLOR_CYAN);
    set_pb_color(CH6_LED, COLOR_VIOLET);
    set_pb_color(CH7_LED, COLOR_WHITE);
    LED_OE_N = 0; // LED controller global enable signal
    

    // Startup animation
    //run_startup_animation(0x30); // 49 cycles
    TMR0_StartTimer();
    while(~TMR0_HasOverflowOccured())
    {
        NOP();
        printf(".");
    }
    
    TMR0_StopTimer();
    TMR0_Reload(TMR0_INIT_VAL);
    PIR0bits.TMR0IF = 0;
    
    boot_msg();
    while (1)
    {
        // Periodic trigger
        if (TMR2_HasOverflowOccured())
        {
            // Status LED blinki
            STATUS_LED = status_led_state;
            status_led_state = ~status_led_state;
            // Get push button states (1 means pressed, bits 0 to 6)
            pb_states = get_pb_states(io_ctrl_addr);
            pb_rising_edges = pb_edge_detect(pb_states);
            pb7_long_press = pb7_long_press_detect(pb_states, pb_rising_edges);
            
            switch (operating_mode)
            {
                case(STARTUP):
                    operating_mode = NORMAL;
                    break;

                case(NORMAL):
                    // PB7 always opens all realays
                    if (pb7_long_press > 0)
                    {
                        printf("PB7 pressed\r\n");
                        relay_states = 0x00;
                        set_relays(io_ctrl_addr, relay_states);
                    }
                    
                    // PB7 long press switches to programming mode
                    if (pb7_long_press == 2)
                    {
                        printf("Entering programming mode\r\n");
                        operating_mode = PROGRAMMING;
                        set_pb_color(CH1_LED, COLOR_OFF);
                        set_pb_color(CH2_LED, COLOR_OFF);
                        set_pb_color(CH3_LED, COLOR_OFF);
                        set_pb_color(CH4_LED, COLOR_OFF);
                        set_pb_color(CH5_LED, COLOR_OFF);
                        set_pb_color(CH6_LED, COLOR_OFF);
                        set_pb_color(CH7_LED, COLOR_OFF);
                    }
                    
                    // PBs 1 to 6 are switching the relays
                    if (pb_rising_edges > 0)
                    {
                        // XORing, example:
                        // 1 0 0 1 1 1 relay_states
                        // 0 1 0 1 0 0 rising_edges
                        // ----------- XOR
                        // 1 1 0 0 1 1
                        printf("RLY: 0x%x\r\n", relay_states);
                        printf("PB POS_EDGES: 0x%x\r\n", pb_rising_edges);
                        relay_states = relay_states ^ pb_rising_edges;
                        printf("XOR: 0x%x\r\n", relay_states);
                        set_relays(io_ctrl_addr, (relay_states));
                    }
                    break;

                case(PROGRAMMING):
                    // PB7 press returns to normal programming mode
                    if (pb7_long_press > 0)
                    {
                        printf("Entering normal mode\r\n");
                        set_pb_color(CH1_LED, COLOR_RED);
                        set_pb_color(CH2_LED, COLOR_GREEN);
                        set_pb_color(CH3_LED, COLOR_BLUE);
                        set_pb_color(CH4_LED, COLOR_YELLOW);
                        set_pb_color(CH5_LED, COLOR_CYAN);
                        set_pb_color(CH6_LED, COLOR_VIOLET);
                        set_pb_color(CH7_LED, COLOR_WHITE);
                        operating_mode = NORMAL;
                    }
                    break;
            }
            
           
            /*set_color2(led_ctrl0_addr, color);
            set_color2(led_ctrl1_addr, color);
            set_color2(led_ctrl2_addr, color);*/
            //set_relays(io_ctrl_addr, pb_states);
            //printf("TEST\r\n");
            //LED_OE_N = pb_states >> 6;
            //PCA9955B_write(led_ctrl4_addr);
            //PCA9955B_read(led_ctrl4_addr); 
        }

    }
}

void handle_operating_mode()
{
    switch (operating_mode)
    {
        case(STARTUP):
            operating_mode = NORMAL;
            break;
        
        case(NORMAL):
            NOP();
            break;
            
        case(PROGRAMMING):
            NOP();
            break;
    }
}

void boot_msg()
{
    printf("\r---------------------------------------------\r\n");
    printf("\r                ReBox Rev. A1                \r\n");
    printf("\r---------------------------------------------\r\n");
    printf("\rFW version: 0.01, build date 2022-02-12\r\n\n");
}

void PCA9955B_init(i2c1_address_t addr)
{
    // LEDs controlled through PWMx or PWMALL register
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.LEDOUT0, 0xAA);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.LEDOUT1, 0xAA);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.LEDOUT2, 0xAA);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.LEDOUT3, 0xAA);
    // Global current & PWM, overwrites group settings
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWMALL, 0x00);
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.IREFALL, LED_CTRL_IREF);
    
    
    // Gradiation control:
    // I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.IREF_GRP0, 0xFF); // IREFALL used
    // Set global current reference to max. value
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.IREFALL, 0xFF);
//    // Ramp up enables, ramp down enabled, ramp rate 16
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.RAMP_RATE_GRP0, 0xC1);
//    // 64*0.5ms ramp up time
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.STEP_TIME_GRP0, 0x04);
//    // Hold ON enable, Hold OFF disable, Hold ON time = x s
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.HOLD_CNTL_GRP0, 0xC9);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.IREF_GRP0, 0xFF); // independant from IREFALL
//    // Enable gradiation mode
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_MODE_SEL0, 0xFF);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_MODE_SEL1, 0xFF);
//    // Assign all LED to gradiation group 0
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_GRP_SEL0, 0x00);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_GRP_SEL1, 0x00);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_GRP_SEL2, 0x00);
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_GRP_SEL3, 0x00);
//    // Run
//    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.GRAD_CNTL, 0x07);
}

/**
 * Reads one register 
 * @param i2c1_address_t device_addr
 * @param uint8_t reg_addr
 */
void PCA9955B_read(i2c1_address_t device_addr, uint8_t reg_addr)
{
    uint8_t val = 0x00;
    val = I2C1_Read1ByteRegister(device_addr, reg_addr);
    printf("0x%x -> 0x%x\r\n", reg_addr, val);
}

/**
 * Sets the led colors (RGB) of one push button
 * @param led_addr_t led_addr
 * @param uint8_t *p_color, pointer to array with 3 elements
 */
void set_pb_color(led_addr_t led_addr, uint8_t *p_color)
{
    uint8_t idx = 0;
    // Three colors (RGB) per push button.
    // Two LEDs per push button. Same color on addresses x and x+3.
    for (idx = 0; idx < 3; idx++)
    {
        I2C1_Write1ByteRegister(led_addr.I2C_ADDR, PCA9955B_ADDR_MAP.PWM0+led_addr.PB_LED_R0 + idx, p_color[idx]);
        I2C1_Write1ByteRegister(led_addr.I2C_ADDR, PCA9955B_ADDR_MAP.PWM0+led_addr.PB_LED_R0 + idx + 3, p_color[idx]);
    }
}

/**
 * Cycles push button colors
 * Uses global variables CHx_LED and COLORS, uses TMR0
 * @param uint8_t n_cycles, number of cycles
 */
void run_startup_animation(uint8_t n_cycles)
{
    uint8_t cycle_counter = 0;
    uint8_t color_counter = 0;
    uint8_t color_indices[7] = {0,3,6,9,12,15,18};
    uint8_t ii = 0;
    uint8_t tmp = 0;
    TMR0_Reload(0x17); // 0.2 s
    TMR0_StartTimer();
    // Cycle loop, one cycle = one color shift
    for (cycle_counter = 0; cycle_counter < n_cycles; cycle_counter++)
    {
        if (~TMR0_HasOverflowOccured())
        {
            set_pb_color(CH1_LED, COLORS+color_indices[0]);
            set_pb_color(CH2_LED, COLORS+color_indices[1]);
            set_pb_color(CH3_LED, COLORS+color_indices[2]);
            set_pb_color(CH4_LED, COLORS+color_indices[3]);
            set_pb_color(CH5_LED, COLORS+color_indices[4]);
            set_pb_color(CH6_LED, COLORS+color_indices[5]);
            set_pb_color(CH7_LED, COLORS+color_indices[6]);
            color_counter++;
            // Cyclic shift of color_indeces
            tmp = color_indices[0];
            for (ii = 0; ii< 6; ii++)
            {
                color_indices[ii] = color_indices[ii+1];
            }
            color_indices[6] = tmp;
        }
    }
    TMR0_StopTimer();
    TMR0_Reload(TMR0_INIT_VAL);
    PIR0bits.TMR0IF = 0;
    
}

void set_color1(i2c1_address_t addr, uint8_t *p_color)
{
    /*
     red = 0,3
     green = 1,4
     blue = 2,5
     */
    uint8_t color_index = 0;
    for (color_index = 0; color_index < 3; color_index++)
    {
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM0+color_index, p_color[color_index]);
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM0+color_index+3, p_color[color_index]);
    }

}

void set_color2(i2c1_address_t addr, uint8_t *p_color)
{
    /*
     red = 0,3
     green = 1,4
     blue = 2,5
     */
    uint8_t color_index = 0;
    for (color_index = 0; color_index < 3; color_index++)
    {
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM0+color_index, p_color[color_index]);
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM0+color_index+3, p_color[color_index]);
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM6+color_index, p_color[color_index]);
        I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM6+color_index+3, p_color[color_index]);
    }
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM12, 0x0F);
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM13, 0x0F);
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM14, 0x0F);
    I2C1_Write1ByteRegister(addr, PCA9955B_ADDR_MAP.PWM15, 0x0F);
}

uint8_t get_pb_states(i2c1_address_t addr)
/*
 * Some extra bit manipulations are required, because of swapped PB numbers
 * on the PCB ;-(
 */
{
    uint8_t pb_states_messed_up; // PBs 5 & 6 are swapped (1 based indexing!)
    uint8_t pb_states;
    pb_states_messed_up = I2C1_Read1ByteRegister(addr, PCA9535_CMD.IN_PORT0);
    pb_states = pb_states_messed_up & 0xCF; // Copy states, but without PBs 6 & 7
    // Swapping...
    // Bit:  7 6 5 4 3 2 1 0
    // PB:   - 7 5 6 4 3 2 1
    // Mask: 0 0 1 0 0 0 0 0 (0x20)
    // Mask: 0 0 0 1 0 0 0 0 (0x10)
    // PB 6 on bit pos. 5: left shift
    pb_states |= (pb_states_messed_up & 0x20) >> 1;
    // PB 5 on bit pos. 6: right shift
    pb_states |= (pb_states_messed_up & 0x10) << 1;

    //printf("SW: 0x%x -> 0x%x\r\n", PCA9535_CMD.IN_PORT0, pb_states);
    // relay_status = I2C1_Read1ByteRegister(addr, PCA9535_CMD.IN_PORT1);
    //printf("RLY: 0x%x -> 0x%x\r\n", PCA9535_CMD.IN_PORT1, pb_states);
    return pb_states;

}

uint8_t io_ctrl_cfg(i2c1_address_t addr, uint16_t cfg_reg_pair, uint16_t out_reg_pair)
{
    uint16_t result;
    // Set relay IOs to 0 before configuring them as output
    I2C1_Write2ByteRegister(addr, PCA9535_CMD.OUT_PORT0, out_reg_pair);
    I2C1_Write2ByteRegister(addr, PCA9535_CMD.CFG_PORT0, cfg_reg_pair);
    /* I2C1_Read2ByteRegister returns high byte first!
     * By reading 2 bytes starting at CFG_PORT1 result contains PORT1
     * in the upper byte, PORT0 at the lower byte.
    */
    result = I2C1_Read2ByteRegister(addr, PCA9535_CMD.OUT_PORT1);
    printf("OUT PORT reg: 0x%x\r\n", result);
    result = I2C1_Read2ByteRegister(addr, PCA9535_CMD.CFG_PORT1);
    printf("CFG reg: 0x%x\r\n", result);
    
    
    if (result != cfg_reg_pair)
    {
        printf("IO_CTRL_CFG failure!\r\n");
        printf("IO-CFG: Wrote 0x%x, got 0x%x\r\n", cfg_reg_pair, result);
        return 1;
    }
    printf("TEST");
    return 0;
}

void set_relays(i2c1_address_t addr, uint8_t relay_states)
/* 
 * Direct mapping from PB input to relay control:
 * PB pressed = 1 = relay closed
 */
{
    printf("SET RLY: 0x%x\r\n", relay_states | RELAY_MASK);
    // RELAY_MASK sets unused channels to high
    I2C1_Write1ByteRegister(addr, PCA9535_CMD.OUT_PORT1, relay_states | RELAY_MASK);
}

uint8_t pb_edge_detect(uint8_t current_state)
/*
 Push button (PB) rising edge detection.
 uint8_t argument contains 8 PB states (every 1 means PB was pressed).
 uint8_t return value contains the rising edgeds, compared to the former PB states.
 The former PB states are stored in local static variable with the inital value 0.
*/
{
    static uint8_t last_state = 0x00;
    uint8_t rising_edges = 0x00;
    rising_edges = current_state & ~last_state; // Get changes from last state
    last_state = current_state; // Store current state
//    if (rising_edges > 0)
//    {
//        printf("PB: 0x%x\r\n",rising_edges);
//    }
    return rising_edges;
    
}

uint8_t pb7_long_press_detect(uint8_t pb_states, uint8_t rising_edges)
/*
 Returns uint8_t value: 0 - nothing happend
                        1 - Short button press detected
                        2 - Long button press detected
 */
{
    static uint8_t button_pressed = 0;
    //printf("TMR0: 0x%x\r\n", TMR0_ReadTimer());
    // Start counter only at rising edges
    if ((rising_edges & PB_MASK.PB7) == PB_MASK.PB7)
    {
        TMR0_StartTimer();
        button_pressed = 1;
        return(1);
    }
    // Time limit for long press reached
    if (TMR0_HasOverflowOccured())
    {
        TMR0_StopTimer();
        PIR0bits.TMR0IF = 0;
        printf("TMR0 Stop: 0x%x\r\n", TMR0_ReadTimer());
        TMR0_WriteTimer(TMR0_INIT_VAL);
        button_pressed = 0; // reset to avoid short button press at next function call
        return(2);
    }
    // PB released prematurely
    if (button_pressed && (pb_states & PB_MASK.PB7) == 0x00)
    {
        button_pressed = 0;
        TMR0_StopTimer();
        TMR0_WriteTimer(TMR0_INIT_VAL);
        return(1);
    }
    
    return(0);
}
/**
 End of File
*/